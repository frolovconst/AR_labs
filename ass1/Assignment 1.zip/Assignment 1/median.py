from numpy import sort

def median_r(data):
    '''
    :param data:
    :return: median element value
    Implement randomized algorithm here
    Use numpy.random.chose function to make a subset R
    '''
    # %%% START YOUR CODE HERE %%%
    # %%% END YOUR CODE HERE %%%


def median_s(data):
    sorted = sort(data)
    return sorted[len(data) // 2]

