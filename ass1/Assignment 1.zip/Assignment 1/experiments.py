from numpy.random import random, randint
from numpy import median
from median import median_r, median_s

from misc import append_gauges, generate_figures, measure_time


def check_results():
    """
    This function checks that you are getting correct results.
    Write your code here to calculate the number of different results
    1) between randomized implementation and numpy median
    2) between randomized implementation and sorting middle element
    """
    sorting_vs_random = []
    numpy_vs_random = []
    sizes = randint(1000000, size=10)

    for size in sizes:
        sorting_vs_random_on_size = 0
        numpy_vs_random_on_size = 0
        for i in range(100):
            data = random(size)
            # %%% START YOUR CODE HERE %%%

            # %%% END YOUR CODE HERE %%%
        sorting_vs_random.append(sorting_vs_random_on_size)
        numpy_vs_random.append(numpy_vs_random_on_size)
    print("sorting vs random different results", sorting_vs_random)
    print("numpy vs random different results", numpy_vs_random)


def check_fails():
    """
    This function checks how often randomized algorithm fails
    """
    fails_number = []
    sizes = []
    for zeros in range(1,9):
        size = 10**zeros
        sizes.append(size)
    for size in sizes:
        fails_on_size = 0
        for i in range(100):
            data = random(size)
            # %%% START YOUR CODE HERE %%%
            # %%% END YOUR CODE HERE %%%
        fails_number.append(fails_on_size)
    print("numbers of fails", fails_number)


def gauge_algorithms(data_size, repeats=100):
    sorting_avg = 0.
    np_avg = 0.
    randomized_avg = 0.

    for i in range(repeats):
        data = random(data_size)
        # %%% START YOUR CODE HERE %%%

    # %%% END YOUR CODE HERE %%%
    return sorting_avg, np_avg, randomized_avg


def check_time_performance():
    sizes = []
    for zeros in range(1,8):
        size = 10**zeros
        sizes.append(size)

    gauges_collection = ([], [], [])
    for size in sizes:
        gauge = gauge_algorithms(size)
        append_gauges(gauges_collection, gauge)
    generate_figures(gauges_collection, "size", sizes)
